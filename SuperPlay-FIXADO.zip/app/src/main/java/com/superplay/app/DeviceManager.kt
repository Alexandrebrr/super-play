package com.superplay.app
class DeviceManager { fun getId(): String = "123" }