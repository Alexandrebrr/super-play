package com.superplay.app
object Constants { const val BASE_URL = "https://google.com" }